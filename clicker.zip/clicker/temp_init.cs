using Godot;

// 임시 C# 스크립트 - C# 프로젝트 초기화용
// 이 파일은 프로젝트 빌드 후 삭제 가능
public partial class TempInit : Node
{
	public override void _Ready()
	{
		GD.Print("C# 프로젝트 초기화 완료!");
	}
}






















